import json
import logging
from pathlib import Path
from logging_setup import configure_cd2_logging


# ---------------------------------------------------------
# Load tables.json
# ---------------------------------------------------------
def load_table_list(path="config/tables.json"):
    with open(path, "r") as f:
        return json.load(f)

# ---------------------------------------------------------
# Placeholder ETL runner for each table
# (We will replace this with real code in later steps)
# ---------------------------------------------------------
import logging
from pathlib import Path
from datetime import datetime, timezone

from dap.api import DAPClient
from dap.integration.database import DatabaseConnection, DatabaseConnectionConfig
from dap.replicator.sql import SQLReplicator

from etl_extract import (
    run_snapshot,
    run_incremental,
    auto_replicate
)

from db_connector import DatabaseConnector


# ---------------------------------------------------------
# Official DAP model: snapshot → initialize → synchronize
# ---------------------------------------------------------
async def process_table(dataset, table_name):
    logging.info(f"Processing {dataset}.{table_name}")

    out_dir = Path(f"data/{dataset}/{table_name}")

    connector = DatabaseConnector.from_secrets("config/secrets.json")
    db_conn = connector.create_connection()

    async with DAPClient() as session:
        replicator = SQLReplicator(session, db_conn)

        # Always upgrade first
        await replicator.version_upgrade()

        # Try initialization
        try:
            logging.info(f"Attempting initialization for {dataset}.{table_name}")
            await run_snapshot(session, dataset, table_name, out_dir)
            await replicator.initialize(dataset, table_name)
            logging.info(f"Initialization completed for {dataset}.{table_name}")
            return
        except ValueError as e:
            if "Table already initialized" in str(e):
                logging.info(f"Table already initialized — performing synchronize()")
            else:
                raise

        # Table already initialized → do synchronize()
        await replicator.synchronize(dataset, table_name)
        logging.info(f"Synchronization completed for {dataset}.{table_name}")


# ---------------------------------------------------------
# Main entry point
# ---------------------------------------------------------
async def main():
    # Start logging
    configure_cd2_logging()
    logging.info("===== CD2 DAP ETL RUN STARTED =====")

    # Load tables
    table_list = load_table_list()
    logging.info(f"Loaded {len(table_list)} tables from tables.json")

    # Loop
    for entry in table_list:
        dataset = entry["dataset"]
        table = entry["table"]

        logging.info(f"--- Starting ETL for {dataset}.{table} ---")
        try:
            await process_table(dataset, table)
            logging.info(f"✔ Completed {dataset}.{table}")
        except Exception as e:
            logging.error(f"❌ ERROR processing {dataset}.{table}: {e}", exc_info=True)

    logging.info("===== CD2 DAP ETL RUN COMPLETE =====")


# ---------------------------------------------------------
# Allow command-line execution
# ---------------------------------------------------------
if __name__ == "__main__":
    import asyncio
    asyncio.run(main())