import logging
from pathlib import Path

def configure_cd2_logging():
    # Ensure logs directory exists
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)

    logging.basicConfig(
        filename="logs/cd2dap_etl.log",
        filemode="w",  # overwrite each run
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s"
    )

    # Also log to console (optional but useful during testing)
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logging.getLogger().addHandler(console)

    logging.info("Logging initialized. Writing to logs/cd2dap_etl.log")