import os
import json
import argparse
import asyncio
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import aiofiles

# Instructure DAP SDK imports

from dap.api import DAPClient
from dap.dap_types import SnapshotQuery, IncrementalQuery, Format
from dap.replicator.sql import SQLReplicator
from dap.log import configure_logging

# Local import (db connector)
from db_connector import DatabaseConnector


# -------------------------------------------------------------
# Load secrets (DAP + DB) from config/secrets.json
# -------------------------------------------------------------
def load_secrets(path: str = "config/secrets.json") -> dict:
    secrets_file = Path(path)

    if not secrets_file.exists():
        raise FileNotFoundError(
            f"Could not find secrets.json at {secrets_file.resolve()}"
        )

    with secrets_file.open("r") as f:
        return json.load(f)


# -------------------------------------------------------------
# Helper functions
# -------------------------------------------------------------
def ensure_output_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


async def save_streamed_resource(session, resource, output_dir: Path):
    """
    Streams a DAP resource to a file on disk.
    """
    components = urlparse(str(resource.url))
    filename = os.path.basename(components.path)
    full_path = output_dir / filename

    async for stream in session.stream_resource(resource):
        async with aiofiles.open(full_path, "wb") as f:
            async for chunk in stream.iter_chunked(64 * 1024):
                await f.write(chunk)

    return full_path


# -------------------------------------------------------------
# SNAPSHOT Download
# -------------------------------------------------------------
async def run_snapshot(session, dataset, table, out_dir: Path):
    ensure_output_dir(out_dir)

    query = SnapshotQuery(
        format=Format.JSONL,
        mode=None
    )

    print("Starting snapshot download...")

    # Correct DAP SDK call
    result = await session.get_table_data(dataset, table, query)

    # Get downloadable resources
    resources = await session.get_resources(result.objects)

    # Download each resource file
    for resource in resources.values():
        await save_streamed_resource(session, resource, out_dir)

    print("Snapshot download complete.")


# -------------------------------------------------------------
# INCREMENTAL Download
# -------------------------------------------------------------
async def run_incremental(session, dataset, table, out_dir: Path, since: datetime):
    ensure_output_dir(out_dir)

    query = IncrementalQuery(
        format=Format.JSONL,
        mode=None,
        since=since,
        until=None
    )

    print(f"Requesting incremental updates since {since.isoformat()}...")
    result = await session.get_table_data(dataset, table, query)
    resources = await session.get_resources(result.objects)

    for r in resources.values():
        await save_streamed_resource(session, r, out_dir)

    # Returned "until" timestamp tells you the next incremental anchor
    until = getattr(result, "until", datetime.now(timezone.utc))
    print(f"Incremental download complete. Next since = {until.isoformat()}")
    return until


# -------------------------------------------------------------
# MAIN EXECUTION LOGIC
# -------------------------------------------------------------
async def main():
    parser = argparse.ArgumentParser(description="Instructure DAP Extraction Utility")

    parser.add_argument("--dataset", required=True)
    parser.add_argument("--table", required=True)

    parser.add_argument(
        "--mode",
        choices=["snapshot", "incremental"],
        required=True
    )

    parser.add_argument(
        "--out-dir",
        default="data",
        help="Directory where processed files will be written"
    )

    parser.add_argument(
        "--since",
        help="ISO timestamp for incremental mode (e.g. 2024-01-01T00:00:00Z)"
    )

    parser.add_argument(
        "--replicate",
        action="store_true",
        help="Enable SQL replication into your database"
    )

    args = parser.parse_args()

    dataset = args.dataset
    table = args.table
    out_dir = Path(args.out_dir)

    # ---------------------------
    # Load all secrets from JSON
    # ---------------------------
    secrets = load_secrets()

    # Inject DAP credentials into environment
    os.environ["DAP_API_URL"] = secrets["DAP_API_URL"]
    os.environ["DAP_CLIENT_ID"] = secrets["DAP_CLIENT_ID"]
    os.environ["DAP_CLIENT_SECRET"] = secrets["DAP_CLIENT_SECRET"]

    # Parse incremental timestamp
    since_dt = None
    if args.mode == "incremental":
        if not args.since:
            raise ValueError("--since is required for incremental mode")
        since_dt = datetime.fromisoformat(args.since.replace("Z", "+00:00"))

    # ---------------------------
    # DAP Client Session
    # ---------------------------
    async with DAPClient() as session:

        # Connection check
        schema = await session.get_table_schema(dataset, table)
        print(f"Connected successfully. Schema object returned: {schema}")

        # Snapshot
        if args.mode == "snapshot":
            await run_snapshot(session, dataset, table, out_dir)

        # Incremental
        if args.mode == "incremental":
            await run_incremental(session, dataset, table, out_dir, since_dt)

        # SQL Replication
        if args.replicate:
            print("Starting SQL replication initialization...")

            connector = DatabaseConnector.from_secrets()   # uses config/secrets.json
            db_con = connector.create_connection()

            replicator = SQLReplicator(session, db_con)
            await replicator.version_upgrade()

            # If table already initialized, run syncdb instead of initialize()
            try:
                await replicator.initialize(dataset, table)
                print("Replication initialization complete.")
            except ValueError as e:
                if "Table already initialized" in str(e):
                    print("Table already initialized — running syncdb instead...")
                    await replicator.sync_table(namespace, table)
                    print("Replication sync complete.")
                else:
                    raise


if __name__ == "__main__":
    asyncio.run(main())
